/* sendpraat.h */
/* Paul Boersma, September 27, 2000 */

char *sendpraat (void *display, const char *programName, long timeOut, const char *text);

/* End of file sendpraat.h */
